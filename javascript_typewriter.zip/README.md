Jefferson Lam
11-20-13
JavaScript Assignment 3

Assignment:
-Clone the codes from: https://github.com/codingdojoco/js_scroll  
-Read the first 5-7 paragraphs about setInterval here: https://developer.mozilla.org/en-US/docs/Web/API/Window.setInterval. Don't worry about the all the advanced examples towards the end but just know that setInterval is an important function you'll have to get very familiar with.  
-Please work on the following features after you go through the codes and understand what's happening.  
-there is a bug where the last character in the word doesn't show up! Please fix this error.  
-there is a bug where the space in the words do not appear correctly. For example for the word "being helpful" when it shows "being " after showing "being" the space should make the right border/cursor move a little bit to the right (to account for the space being entered by the user) yet it doesn't work correctly. Please fix this error. (Hint: you may want to use &nbsp; to represent space).  
-the current codes are creating lots of global variables. we don't like this. use what you learned about immediate function to wrap all of those codes in a single immediate function so that you don't introduce any global variables. Once done, put this in your GitHub and show your friends! To check whether the variables you created (e.g. el, word_counter, etc) are not global variables, try to console.log these variables outside the immediate function to make sure these variables are not accessible outside the immediate function).  
-submit a pull request through GitHub. :)  
-put this on your GitHub; also upload a simple txt file with a link to your GitHub project for us to review
